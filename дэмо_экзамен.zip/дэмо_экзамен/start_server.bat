@echo off
chcp 65001 >nul
title ООО СтройМатериалы - Django Server

cd /d "%~dp0"

echo ============================================
echo   ООО «СтройМатериалы» - Запуск сервера
echo ============================================
echo.

if not exist "venv\Scripts\activate.bat" (
    echo Создание виртуального окружения...
    python -m venv venv
)

call venv\Scripts\activate.bat

echo Установка зависимостей...
pip install -r requirements.txt -q

if not exist "db.sqlite3" (
    echo Применение миграций...
    python manage.py migrate
    echo Импорт данных...
    python manage.py import_data --import-dir import_data
)

echo.
echo Сервер запущен: http://127.0.0.1:8000/
echo Для остановки нажмите Ctrl+C
echo.

python manage.py runserver 8000

pause
