from django.contrib import admin

from .models import (
    AppUser,
    Category,
    Manufacturer,
    Order,
    OrderItem,
    OrderStatus,
    PickupPoint,
    Product,
    Role,
)


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    search_fields = ('name',)


@admin.register(AppUser)
class AppUserAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'login', 'role')
    list_filter = ('role',)
    search_fields = ('full_name', 'login')


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    search_fields = ('name',)


@admin.register(Manufacturer)
class ManufacturerAdmin(admin.ModelAdmin):
    search_fields = ('name',)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('article', 'name', 'price', 'stock_quantity', 'discount')
    list_filter = ('category', 'manufacturer')
    search_fields = ('article', 'name')


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('order_number', 'order_date', 'delivery_date', 'status', 'client')
    inlines = [OrderItemInline]


admin.site.register(OrderStatus)
admin.site.register(PickupPoint)
