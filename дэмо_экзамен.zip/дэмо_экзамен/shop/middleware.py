from django.utils.deprecation import MiddlewareMixin

from .models import AppUser


class AppUserMiddleware(MiddlewareMixin):
    def process_request(self, request):
        request.app_user = None
        user_id = request.session.get('app_user_id')
        if user_id:
            request.app_user = AppUser.objects.filter(
                pk=user_id,
                is_active=True,
            ).select_related('role').first()
