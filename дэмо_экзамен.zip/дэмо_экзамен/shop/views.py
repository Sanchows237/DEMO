from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages

from .decorators import admin_required, guest_or_auth_required, login_required, orders_access_required
from .forms import LoginForm, OrderForm, ProductForm
from .models import AppUser, Manufacturer, Order, OrderItem, Product
from .utils import delete_product_image, get_user_display_name, save_product_image


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            login_value = form.cleaned_data['login']
            password = form.cleaned_data['password']
            user = AppUser.objects.filter(login=login_value, is_active=True).select_related('role').first()
            if user and user.check_password(password):
                request.session.flush()
                request.session['app_user_id'] = user.pk
                return redirect('shop:product_list')
            messages.error(
                request,
                'Неверный логин или пароль. Проверьте введённые данные и попробуйте снова.',
            )
    else:
        form = LoginForm()

    return render(request, 'shop/login.html', {
        'form': form,
        'page_title': 'Авторизация',
    })


def guest_login_view(request):
    if request.method == 'POST':
        request.session.flush()
        request.session['is_guest'] = True
        return redirect('shop:product_list')
    return redirect('shop:login')


def logout_view(request):
    request.session.flush()
    return redirect('shop:login')


@guest_or_auth_required
def product_list_view(request):
    request.session.pop('product_edit_lock', None)
    products = Product.objects.select_related('category', 'manufacturer').all()
    can_filter = request.app_user and request.app_user.can_filter_products
    can_manage = request.app_user and request.app_user.can_manage_products
    can_view_orders = request.app_user and request.app_user.can_view_orders

    search_query = ''
    manufacturer_filter = ''
    sort_field = ''
    sort_direction = 'asc'

    if can_filter:
        search_query = request.GET.get('search', '').strip()
        manufacturer_filter = request.GET.get('manufacturer', '').strip()
        sort_field = request.GET.get('sort', '').strip()
        sort_direction = request.GET.get('direction', 'asc').strip()

        if search_query:
            products = products.filter(
                Q(article__icontains=search_query)
                | Q(name__icontains=search_query)
                | Q(description__icontains=search_query)
                | Q(supplier__icontains=search_query)
                | Q(unit__icontains=search_query)
                | Q(category__name__icontains=search_query)
                | Q(manufacturer__name__icontains=search_query)
            )

        if manufacturer_filter:
            products = products.filter(manufacturer_id=manufacturer_filter)

        sort_map = {
            'stock': 'stock_quantity',
            'price': 'price',
            'discount': 'discount',
        }
        if sort_field in sort_map:
            order_prefix = '-' if sort_direction == 'desc' else ''
            products = products.order_by(f'{order_prefix}{sort_map[sort_field]}')

    manufacturers = Manufacturer.objects.order_by('name') if can_filter else []

    return render(request, 'shop/product_list.html', {
        'products': products,
        'page_title': 'Список товаров',
        'user_name': get_user_display_name(request),
        'can_filter': can_filter,
        'can_manage': can_manage,
        'can_view_orders': can_view_orders,
        'search_query': search_query,
        'manufacturer_filter': manufacturer_filter,
        'sort_field': sort_field,
        'sort_direction': sort_direction,
        'manufacturers': manufacturers,
    })


@admin_required
def product_add_view(request):
    if request.session.get('product_edit_lock'):
        messages.warning(
            request,
            'Невозможно открыть форму добавления: уже открыто окно редактирования товара.',
        )
        return redirect('shop:product_list')

    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            product = form.save(commit=False)
            uploaded_image = form.cleaned_data.get('image')
            if uploaded_image:
                product.image_path = save_product_image(uploaded_image, product.article)
            product.save()
            messages.success(request, f'Товар «{product.name}» успешно добавлен.')
            return redirect('shop:product_list')
    else:
        form = ProductForm()

    return render(request, 'shop/product_form.html', {
        'form': form,
        'page_title': 'Добавление товара',
        'user_name': get_user_display_name(request),
        'is_edit': False,
    })


@admin_required
def product_edit_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    lock_key = 'product_edit_lock'
    locked_product_id = request.session.get(lock_key)

    if locked_product_id and locked_product_id != product.pk:
        messages.warning(
            request,
            'Невозможно открыть второе окно редактирования. Завершите редактирование текущего товара.',
        )
        return redirect('shop:product_list')

    request.session[lock_key] = product.pk

    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            updated_product = form.save(commit=False)
            uploaded_image = form.cleaned_data.get('image')
            if uploaded_image:
                delete_product_image(updated_product.image_path)
                updated_product.image_path = save_product_image(uploaded_image, updated_product.article)
            updated_product.save()
            request.session.pop(lock_key, None)
            messages.success(request, f'Товар «{updated_product.name}» успешно обновлён.')
            return redirect('shop:product_list')
    else:
        form = ProductForm(instance=product)

    return render(request, 'shop/product_form.html', {
        'form': form,
        'product': product,
        'page_title': 'Редактирование товара',
        'user_name': get_user_display_name(request),
        'is_edit': True,
    })


@admin_required
def product_delete_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if OrderItem.objects.filter(product=product).exists():
        messages.error(
            request,
            f'Невозможно удалить товар «{product.name}»: он присутствует в заказе.',
        )
        return redirect('shop:product_list')

    if request.method == 'POST':
        product_name = product.name
        delete_product_image(product.image_path)
        product.delete()
        messages.success(request, f'Товар «{product_name}» удалён.')
        return redirect('shop:product_list')

    return render(request, 'shop/product_confirm_delete.html', {
        'product': product,
        'page_title': 'Удаление товара',
        'user_name': get_user_display_name(request),
    })


@orders_access_required
def order_list_view(request):
    orders = Order.objects.select_related('pickup_point', 'client', 'status').prefetch_related('items__product')
    can_manage = request.app_user.can_manage_products

    return render(request, 'shop/order_list.html', {
        'orders': orders,
        'page_title': 'Заказы',
        'user_name': get_user_display_name(request),
        'can_manage': can_manage,
    })


@admin_required
def order_add_view(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save()
            OrderItem.objects.filter(order=order).delete()
            for product, quantity in form.cleaned_data['parsed_items']:
                OrderItem.objects.create(order=order, product=product, quantity=quantity)
            messages.success(request, f'Заказ №{order.order_number} успешно добавлен.')
            return redirect('shop:order_list')
    else:
        next_number = (Order.objects.order_by('-order_number').values_list('order_number', flat=True).first() or 0) + 1
        form = OrderForm(initial={'order_number': next_number})

    return render(request, 'shop/order_form.html', {
        'form': form,
        'page_title': 'Добавление заказа',
        'user_name': get_user_display_name(request),
        'is_edit': False,
    })


@admin_required
def order_edit_view(request, pk):
    order = get_object_or_404(Order, pk=pk)

    if request.method == 'POST':
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            order = form.save()
            OrderItem.objects.filter(order=order).delete()
            for product, quantity in form.cleaned_data['parsed_items']:
                OrderItem.objects.create(order=order, product=product, quantity=quantity)
            messages.success(request, f'Заказ №{order.order_number} успешно обновлён.')
            return redirect('shop:order_list')
    else:
        form = OrderForm(instance=order)

    return render(request, 'shop/order_form.html', {
        'form': form,
        'order': order,
        'page_title': 'Редактирование заказа',
        'user_name': get_user_display_name(request),
        'is_edit': True,
    })


@admin_required
def order_delete_view(request, pk):
    order = get_object_or_404(Order, pk=pk)

    if request.method == 'POST':
        order_number = order.order_number
        order.delete()
        messages.success(request, f'Заказ №{order_number} удалён.')
        return redirect('shop:order_list')

    return render(request, 'shop/order_confirm_delete.html', {
        'order': order,
        'page_title': 'Удаление заказа',
        'user_name': get_user_display_name(request),
    })
