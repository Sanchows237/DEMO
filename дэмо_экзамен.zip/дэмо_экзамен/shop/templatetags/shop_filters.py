from django import template

register = template.Library()


@register.filter
def final_price(product):
    return product.final_price
