from django import template

register = template.Library()


@register.simple_tag
def product_image_url(product):
    if product.image_path:
        return f'/media/{product.image_path}'
    return '/static/shop/picture.png'
