from decimal import Decimal

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.core.validators import MinValueValidator
from django.db import models


class Role(models.Model):
    name = models.CharField('Роль', max_length=100, unique=True)

    class Meta:
        verbose_name = 'Роль'
        verbose_name_plural = 'Роли'

    def __str__(self):
        return self.name


class AppUserManager(BaseUserManager):
    def create_user(self, login, password=None, **extra_fields):
        if not login:
            raise ValueError('Логин обязателен')
        user = self.model(login=login, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user


class AppUser(AbstractBaseUser):
    full_name = models.CharField('ФИО', max_length=255)
    login = models.EmailField('Логин', unique=True)
    role = models.ForeignKey(
        Role,
        on_delete=models.PROTECT,
        verbose_name='Роль',
        related_name='users',
    )
    is_active = models.BooleanField(default=True)

    objects = AppUserManager()

    USERNAME_FIELD = 'login'
    REQUIRED_FIELDS = ['full_name']

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'

    def __str__(self):
        return self.full_name

    @property
    def is_administrator(self):
        return self.role.name == 'Администратор'

    @property
    def is_manager(self):
        return self.role.name == 'Менеджер'

    @property
    def is_client(self):
        return self.role.name == 'Авторизированный клиент'

    @property
    def can_manage_products(self):
        return self.is_administrator

    @property
    def can_filter_products(self):
        return self.is_administrator or self.is_manager

    @property
    def can_view_orders(self):
        return self.is_administrator or self.is_manager


class Category(models.Model):
    name = models.CharField('Категория', max_length=255, unique=True)

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'

    def __str__(self):
        return self.name


class Manufacturer(models.Model):
    name = models.CharField('Производитель', max_length=255, unique=True)

    class Meta:
        verbose_name = 'Производитель'
        verbose_name_plural = 'Производители'

    def __str__(self):
        return self.name


class Product(models.Model):
    article = models.CharField('Артикул', max_length=20, unique=True)
    name = models.CharField('Наименование', max_length=255)
    category = models.ForeignKey(
        Category,
        on_delete=models.PROTECT,
        verbose_name='Категория',
        related_name='products',
    )
    description = models.TextField('Описание', blank=True)
    manufacturer = models.ForeignKey(
        Manufacturer,
        on_delete=models.PROTECT,
        verbose_name='Производитель',
        related_name='products',
    )
    supplier = models.CharField('Поставщик', max_length=255)
    price = models.DecimalField(
        'Цена',
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0'))],
    )
    unit = models.CharField('Единица измерения', max_length=50)
    stock_quantity = models.PositiveIntegerField('Количество на складе', default=0)
    discount = models.PositiveIntegerField('Действующая скидка', default=0)
    image_path = models.CharField('Путь к изображению', max_length=255, blank=True)

    class Meta:
        verbose_name = 'Товар'
        verbose_name_plural = 'Товары'
        ordering = ['article']

    def __str__(self):
        return self.name

    @property
    def final_price(self):
        if self.discount:
            return self.price * (100 - self.discount) / 100
        return self.price

    @property
    def has_discount(self):
        return self.discount > 0

    @property
    def high_discount(self):
        return self.discount > 12

    @property
    def out_of_stock(self):
        return self.stock_quantity == 0


class PickupPoint(models.Model):
    address = models.CharField('Адрес', max_length=500, unique=True)

    class Meta:
        verbose_name = 'Пункт выдачи'
        verbose_name_plural = 'Пункты выдачи'

    def __str__(self):
        return self.address


class OrderStatus(models.Model):
    name = models.CharField('Статус', max_length=100, unique=True)

    class Meta:
        verbose_name = 'Статус заказа'
        verbose_name_plural = 'Статусы заказов'

    def __str__(self):
        return self.name


class Order(models.Model):
    order_number = models.PositiveIntegerField('Номер заказа', unique=True)
    order_date = models.DateField('Дата заказа', null=True, blank=True)
    delivery_date = models.DateField('Дата выдачи', null=True, blank=True)
    pickup_point = models.ForeignKey(
        PickupPoint,
        on_delete=models.PROTECT,
        verbose_name='Пункт выдачи',
        related_name='orders',
    )
    client = models.ForeignKey(
        AppUser,
        on_delete=models.PROTECT,
        verbose_name='Клиент',
        related_name='orders',
        limit_choices_to={'role__name': 'Авторизированный клиент'},
    )
    pickup_code = models.PositiveIntegerField('Код для получения', default=0)
    status = models.ForeignKey(
        OrderStatus,
        on_delete=models.PROTECT,
        verbose_name='Статус',
        related_name='orders',
    )

    class Meta:
        verbose_name = 'Заказ'
        verbose_name_plural = 'Заказы'
        ordering = ['order_number']

    def __str__(self):
        return f'Заказ №{self.order_number}'

    @property
    def articles_display(self):
        items = self.items.select_related('product').all()
        return ', '.join(f'{item.product.article}, {item.quantity}' for item in items)


class OrderItem(models.Model):
    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name='items',
        verbose_name='Заказ',
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name='order_items',
        verbose_name='Товар',
    )
    quantity = models.PositiveIntegerField('Количество', default=1)

    class Meta:
        verbose_name = 'Позиция заказа'
        verbose_name_plural = 'Позиции заказа'
        unique_together = ('order', 'product')

    def __str__(self):
        return f'{self.product.article} x {self.quantity}'
