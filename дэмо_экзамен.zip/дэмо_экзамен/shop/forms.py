from decimal import Decimal

from django import forms
from django.core.exceptions import ValidationError

from .models import Category, Manufacturer, Order, OrderStatus, PickupPoint, Product


class LoginForm(forms.Form):
    login = forms.EmailField(
        label='Логин',
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'example@mail.com'}),
    )
    password = forms.CharField(
        label='Пароль',
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
    )


class ProductForm(forms.ModelForm):
    image = forms.ImageField(
        label='Фото товара',
        required=False,
        widget=forms.FileInput(attrs={'class': 'form-control form-control-sm', 'accept': 'image/*'}),
    )

    class Meta:
        model = Product
        fields = [
            'article',
            'name',
            'category',
            'description',
            'manufacturer',
            'supplier',
            'price',
            'unit',
            'stock_quantity',
            'discount',
        ]
        widgets = {
            'article': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'name': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'category': forms.Select(attrs={'class': 'form-select form-control-sm'}),
            'description': forms.Textarea(attrs={'class': 'form-control form-control-sm', 'rows': 2}),
            'manufacturer': forms.Select(attrs={'class': 'form-select form-control-sm'}),
            'supplier': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'price': forms.NumberInput(attrs={'class': 'form-control form-control-sm', 'step': '0.01', 'min': '0'}),
            'unit': forms.TextInput(attrs={'class': 'form-control form-control-sm'}),
            'stock_quantity': forms.NumberInput(attrs={'class': 'form-control form-control-sm', 'min': '0'}),
            'discount': forms.NumberInput(attrs={'class': 'form-control form-control-sm', 'min': '0', 'max': '100'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].queryset = Category.objects.order_by('name')
        self.fields['manufacturer'].queryset = Manufacturer.objects.order_by('name')
        if self.instance.pk:
            self.fields['article'].widget.attrs['readonly'] = True


class OrderForm(forms.ModelForm):
    articles = forms.CharField(
        label='Артикулы',
        help_text='Формат: артикул, количество, артикул, количество (например: PMEZMH, 2, BPV4MM, 2)',
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
    )

    class Meta:
        model = Order
        fields = [
            'order_number',
            'status',
            'pickup_point',
            'order_date',
            'delivery_date',
            'client',
            'pickup_code',
        ]
        widgets = {
            'order_number': forms.NumberInput(attrs={'class': 'form-control', 'min': '1'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
            'pickup_point': forms.Select(attrs={'class': 'form-select'}),
            'order_date': forms.DateInput(
                attrs={'class': 'form-control', 'type': 'date'},
                format='%Y-%m-%d',
            ),
            'delivery_date': forms.DateInput(
                attrs={'class': 'form-control', 'type': 'date'},
                format='%Y-%m-%d',
            ),
            'client': forms.Select(attrs={'class': 'form-select'}),
            'pickup_code': forms.NumberInput(attrs={'class': 'form-control', 'min': '0'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['status'].queryset = OrderStatus.objects.order_by('name')
        self.fields['pickup_point'].queryset = PickupPoint.objects.order_by('address')
        if self.instance.pk:
            self.fields['articles'].initial = self.instance.articles_display
            self.fields['order_number'].widget.attrs['readonly'] = True
        self.fields['order_date'].input_formats = ['%Y-%m-%d']
        self.fields['delivery_date'].input_formats = ['%Y-%m-%d']

    def clean_articles(self):
        raw_value = self.cleaned_data['articles']
        parts = [part.strip() for part in raw_value.split(',') if part.strip()]
        if len(parts) % 2 != 0:
            raise ValidationError(
                'Неверный формат артикулов. Укажите пары «артикул, количество» через запятую.'
            )

        parsed_items = []
        for index in range(0, len(parts), 2):
            article = parts[index]
            try:
                quantity = int(parts[index + 1])
            except ValueError as exc:
                raise ValidationError(
                    f'Количество для артикула «{article}» должно быть целым числом.'
                ) from exc
            if quantity <= 0:
                raise ValidationError(
                    f'Количество для артикула «{article}» должно быть больше нуля.'
                )
            product = Product.objects.filter(article=article).first()
            if not product:
                raise ValidationError(f'Товар с артикулом «{article}» не найден в базе данных.')
            parsed_items.append((product, quantity))

        self.cleaned_data['parsed_items'] = parsed_items
        return raw_value
