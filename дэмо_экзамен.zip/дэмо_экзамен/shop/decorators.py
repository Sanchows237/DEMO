from django.shortcuts import redirect
from django.urls import reverse

from .models import AppUser


class AppUserMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.app_user = None
        user_id = request.session.get('app_user_id')
        if user_id:
            request.app_user = AppUser.objects.filter(pk=user_id, is_active=True).select_related('role').first()
        return self.get_response(request)


def login_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.session.get('is_guest') or request.app_user:
            return view_func(request, *args, **kwargs)
        return redirect('shop:login')

    return wrapper


def guest_or_auth_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.session.get('is_guest') or request.app_user:
            return view_func(request, *args, **kwargs)
        return redirect('shop:login')

    return wrapper


def admin_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.app_user and request.app_user.can_manage_products:
            return view_func(request, *args, **kwargs)
        from django.contrib import messages
        messages.error(request, 'Доступ запрещён. Действие доступно только администратору.')
        return redirect('shop:product_list')

    return wrapper


def orders_access_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.app_user and request.app_user.can_view_orders:
            return view_func(request, *args, **kwargs)
        from django.contrib import messages
        messages.error(request, 'Просмотр заказов доступен только менеджеру и администратору.')
        return redirect('shop:product_list')

    return wrapper
