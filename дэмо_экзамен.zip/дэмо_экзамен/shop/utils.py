from io import BytesIO
from pathlib import Path

from django.conf import settings
from PIL import Image


def save_product_image(uploaded_file, article):
    products_dir = Path(settings.MEDIA_ROOT) / 'products'
    products_dir.mkdir(parents=True, exist_ok=True)

    image = Image.open(uploaded_file)
    image = image.convert('RGB')
    image.thumbnail((300, 200), Image.Resampling.LANCZOS)

    buffer = BytesIO()
    image.save(buffer, format='JPEG', quality=85)
    buffer.seek(0)

    filename = f'{article}.jpg'
    file_path = products_dir / filename
    with open(file_path, 'wb') as output_file:
        output_file.write(buffer.read())

    return f'products/{filename}'


def delete_product_image(image_path):
    if not image_path:
        return
    full_path = Path(settings.MEDIA_ROOT) / image_path
    if full_path.exists():
        full_path.unlink()


def get_user_display_name(request):
    if request.session.get('is_guest'):
        return 'Гость'
    user = getattr(request, 'app_user', None)
    if user:
        return user.full_name
    return ''
