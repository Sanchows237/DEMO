import os
from datetime import datetime
from decimal import Decimal

import openpyxl
from django.conf import settings
from django.core.management.base import BaseCommand

from shop.models import (
    AppUser,
    Category,
    Manufacturer,
    Order,
    OrderItem,
    OrderStatus,
    PickupPoint,
    Product,
    Role,
)


class Command(BaseCommand):
    help = 'Импорт данных из Excel-файлов задания'

    def add_arguments(self, parser):
        parser.add_argument(
            '--import-dir',
            type=str,
            default='',
            help='Путь к папке import с Excel-файлами',
        )

    def handle(self, *args, **options):
        import_dir = options['import_dir']
        if not import_dir:
            import_dir = os.path.join(
                settings.BASE_DIR.parent,
                'ДЭМО Экзамен',
                'Прил_В3_КОД 09.02.07-2-2026-ПУ',
                'Модуль 1',
                'Прил_2_ОЗ_КОД 09.02.07-2-2026-М1',
                'import',
            )
            if not os.path.exists(import_dir):
                import_dir = os.path.join(settings.BASE_DIR, 'import_data')

        self.stdout.write(f'Импорт из: {import_dir}')

        self._import_roles_and_users(import_dir)
        self._import_products(import_dir)
        self._import_pickup_points(import_dir)
        self._import_orders(import_dir)

        self.stdout.write(self.style.SUCCESS('Импорт завершён успешно'))

    def _import_roles_and_users(self, import_dir):
        role_names = ['Администратор', 'Менеджер', 'Авторизированный клиент']
        for role_name in role_names:
            Role.objects.get_or_create(name=role_name)

        workbook = openpyxl.load_workbook(os.path.join(import_dir, 'user_import.xlsx'))
        rows = list(workbook.active.iter_rows(values_only=True))[1:]

        for row in rows:
            if not row[0]:
                continue
            role = Role.objects.get(name=row[0].strip())
            full_name = row[1].strip()
            login = row[2].strip()
            password = row[3].strip()
            user, created = AppUser.objects.get_or_create(
                login=login,
                defaults={'full_name': full_name, 'role': role},
            )
            if not created:
                user.full_name = full_name
                user.role = role
            user.set_password(password)
            user.save()

    def _import_products(self, import_dir):
        workbook = openpyxl.load_workbook(os.path.join(import_dir, 'Tovar.xlsx'))
        rows = list(workbook.active.iter_rows(values_only=True))[1:]

        for row in rows:
            if not row[0]:
                continue
            article = str(row[0]).strip()
            category, _ = Category.objects.get_or_create(name=row[6].strip())
            manufacturer, _ = Manufacturer.objects.get_or_create(name=row[5].strip())
            image_name = row[10]
            image_path = ''
            if image_name:
                image_path = self._resolve_image_path(import_dir, str(image_name).strip())

            Product.objects.update_or_create(
                article=article,
                defaults={
                    'name': row[1].strip(),
                    'unit': row[2].strip(),
                    'price': Decimal(str(row[3])),
                    'supplier': row[4].strip(),
                    'manufacturer': manufacturer,
                    'category': category,
                    'discount': int(row[7] or 0),
                    'stock_quantity': int(row[8] or 0),
                    'description': (row[9] or '').strip(),
                    'image_path': image_path,
                },
            )

    def _resolve_image_path(self, import_dir, image_name):
        base_name = os.path.splitext(image_name)[0]
        for extension in ('.jpg', '.jpeg', '.png', '.JPG', '.JPEG', '.PNG'):
            candidate = os.path.join(import_dir, base_name + extension)
            if os.path.exists(candidate):
                media_dir = os.path.join(settings.MEDIA_ROOT, 'products')
                os.makedirs(media_dir, exist_ok=True)
                target_name = base_name + extension.lower().replace('.jpeg', '.jpg')
                if target_name.endswith('.png'):
                    target_name = base_name + '.jpg'
                target_path = os.path.join(media_dir, os.path.basename(target_name))
                if not os.path.exists(target_path):
                    import shutil
                    shutil.copy2(candidate, target_path)
                return f'products/{os.path.basename(target_path)}'
        return ''

    def _import_pickup_points(self, import_dir):
        workbook = openpyxl.load_workbook(os.path.join(import_dir, 'Пункты выдачи_import.xlsx'))
        rows = workbook.active.iter_rows(values_only=True)
        for row in rows:
            if not row[0]:
                continue
            address = str(row[0]).strip()
            PickupPoint.objects.get_or_create(address=address)

    def _import_orders(self, import_dir):
        workbook = openpyxl.load_workbook(os.path.join(import_dir, 'Заказ_import.xlsx'))
        rows = list(workbook.active.iter_rows(values_only=True))[1:]
        pickup_points = list(PickupPoint.objects.order_by('id'))

        for row in rows:
            if not row[0]:
                continue
            order_number = int(row[0])
            articles_raw = str(row[1]).strip()
            order_date = self._parse_date(row[2])
            delivery_date = self._parse_date(row[3])
            pickup_index = int(row[4]) - 1
            client_name = row[5].strip()
            pickup_code = int(row[6])
            status_name = row[7].strip() if row[7] else 'Новый'

            status, _ = OrderStatus.objects.get_or_create(name=status_name)
            client = AppUser.objects.filter(full_name=client_name).first()
            if not client:
                client_role = Role.objects.get(name='Авторизированный клиент')
                client = AppUser.objects.create(
                    full_name=client_name,
                    login=f'client_{order_number}@import.local',
                    role=client_role,
                )
                client.set_password('import')
                client.save()

            pickup_point = pickup_points[pickup_index]

            order, _ = Order.objects.update_or_create(
                order_number=order_number,
                defaults={
                    'order_date': order_date,
                    'delivery_date': delivery_date,
                    'pickup_point': pickup_point,
                    'client': client,
                    'pickup_code': pickup_code,
                    'status': status,
                },
            )

            OrderItem.objects.filter(order=order).delete()
            parts = [part.strip() for part in articles_raw.split(',')]
            for index in range(0, len(parts), 2):
                article = parts[index]
                quantity = int(parts[index + 1])
                product = Product.objects.filter(article=article).first()
                if product:
                    OrderItem.objects.create(order=order, product=product, quantity=quantity)

    def _parse_date(self, value):
        if value is None:
            return None
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, str):
            value = value.strip()
            for date_format in ('%d.%m.%Y', '%Y-%m-%d'):
                try:
                    return datetime.strptime(value, date_format).date()
                except ValueError:
                    continue
        return None
